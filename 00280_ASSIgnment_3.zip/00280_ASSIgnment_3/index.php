<?php
    // getting all values from the HTML form
    if(isset($_POST['submit']))
    {
        $TxtFirstname = $_POST['TxtFirstname'];
        $TxtLastname = $_POST['TxtLastname'];
        $TxtEmailid = $_POST['TxtEmailid'];
        $Feedback = $_POST['Feedback'];
    }

    // database details
    $host = "localhost";
    $username = "root";
    $password = "";
    $dbname = "harshang";

    // creating a connection
    $con = mysqli_connect($host, $username, $password, $dbname);

    // to ensure that the connection is made
    if (!$con)
    {
        die("Connection failed!" . mysqli_connect_error());
    }

    // using sql to create a data entry query
    $sql = "INSERT INTO feed( TxtFirstname, TxtLastname, TxtEmailid,Feedback) VALUES ( '$TxtFirstname', '$TxtLastname', '$TxtEmailid','$Feedback')";
  
    // send query to the database to add values and confirm if successful
    $rs = mysqli_query($con, $sql);
    if($rs)
    {
        echo "Entries added!";
    }
  